// SecondPage.dart
import 'package:flutter/material.dart';

class SecondPage extends StatelessWidget {
  final String searchText;

  // Constructor to receive the search text
  const SecondPage({super.key, required this.searchText});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF202125),
        title: const Text(
          'Search Result',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Container(
        color: const Color(0xFF303135),
        child: Center(
          child: Text(
            'Hi, $searchText', // Show the input text with "Hi, "
            style: const TextStyle(color: Colors.white, fontSize: 24),
          ),
        ),
      ),
    );
  }
}
