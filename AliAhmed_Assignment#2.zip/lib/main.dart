import 'package:flutter/material.dart';
import 'secondPage.dart'; // Import the second page

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: FirstPage(),
    );
  }
}

class FirstPage extends StatefulWidget {
  const FirstPage({super.key});

  @override
  FirstPageState createState() => FirstPageState();
}

class FirstPageState extends State<FirstPage> {
  final TextEditingController _searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF202125),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            const Text(
              'Gmail',
              style: TextStyle(
                color: Color(0xFFf6f7f6),
                fontSize: 14,
                fontFamily: 'Roboto',
              ),
            ),
            const SizedBox(width: 20),
            const Text(
              'Images',
              style: TextStyle(
                color: Color(0xFFf6f7f6),
                fontSize: 14,
                fontFamily: 'Roboto',
              ),
            ),
            const SizedBox(width: 16),
            IconButton(
              icon: Image.asset('icons/icon.png'),
              onPressed: () {},
            ),
            const SizedBox(width: 16),
            ClipOval(
              child: Container(
                width: 28,
                height: 28,
                decoration:
                    BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                child: Image.asset(
                  'images/flutter_icon.png',
                  fit: BoxFit.scaleDown,
                ),
              ),
            ),
          ],
        ),
      ),
      body: Container(
        color: const Color(0xFF303135),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 140),
              const Text(
                'Google',
                style: TextStyle(
                  fontSize: 100,
                  fontFamily: 'Lato',
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 700,
                      height: 45,
                      child: TextField(
                        controller: _searchController,
                        style: const TextStyle(
                          color: Colors.white60, // Set the text color here
                        ),
                        decoration: InputDecoration(
                          hintText: 'Search Google or type a URL',
                          hintStyle: const TextStyle(
                            color: Colors.white60,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          fillColor: const Color.fromARGB(255, 52, 54, 59),
                          filled: true,
                          prefixIcon: IconButton(
                            icon:
                                const Icon(Icons.search, color: Colors.white60),
                            onPressed: () {},
                          ),
                          suffixIcon: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.mic,
                                    color: Colors.white60),
                                onPressed: () {},
                              ),
                              IconButton(
                                icon: const Icon(Icons.camera_alt,
                                    color: Colors.white60),
                                onPressed: () {},
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      if (_searchController.text.isNotEmpty) {
                        // Navigate to the second page with the search text
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SecondPage(
                              searchText: _searchController.text,
                            ),
                          ),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 62, 64, 70),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 10),
                    ),
                    child: const Text(
                      'Google Search',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(width: 20),
                  ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 62, 63, 71),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 10),
                    ),
                    child: const Text(
                      "I'm Feeling Lucky",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            color: const Color(0xFF171717),
            height: 50,
            child: const Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Text(
                  'Pakistan',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
          Container(
            color: Colors.grey.shade600,
            height: 1,
          ),
          Container(
            color: const Color(0xFF171717),
            height: 50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Padding(
                  padding: EdgeInsets.only(left: 26.0),
                  child: Text(
                    'About       Advertising       Business      How Search works',
                    style: TextStyle(color: Colors.white, fontSize: 13),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.only(right: 26.0),
                  child: Text(
                    'Privacy       Terms       Settings',
                    style: TextStyle(color: Colors.white, fontSize: 13),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
